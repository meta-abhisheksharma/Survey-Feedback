package main.java.com.survey.model;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.stereotype.Repository;


@Repository
@Entity
@Table(name=" ")
public class UserSurveys {

	private String userID;
	private String surveyID;
		
	
}
